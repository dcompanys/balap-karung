class pemain {
  constructor(x, y, warna) {
    this.d = 50
    this.x = x
    this.y = y
    this.warna = color(warna)
    this.loncat = 10
  }
  
  tampilkan(){
    image(imgpemain, this.x, this.y, 90, 90)
  }
  
  maju(){
    this.x += this.loncat
  }
  
  cekFinish(){
    if(this.x > x1){
      fill(this.warna)
      textSize(50)
      textAlign(CENTER)
      text('FINISH', width/2, height/2)
    }
  }
}