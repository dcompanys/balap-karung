let pemain1, pemain2
let x1, x2, y1, y2
let bg, imgpemain
function preload() {
  bg = loadImage("lapangan.jpeg")
  imgpemain = loadImage("pemain1.png")
}

function setup() {
  createCanvas(600, 400);
  x1 = 385
  y1 = height/2 + 20
  x2 = x1 - 50
  y2 = 355
  
  pemain1 = new pemain(70, 200, 'red')
  pemain2 = new pemain(50, height-130, 'blue')
}

function draw(){
  image(bg, 0,0, width, height)
  line(x1, y1, x2, y2)
  
  pemain1.tampilkan()
  pemain2.tampilkan()
  
  pemain1.cekFinish()
  pemain2.cekFinish()
}

function keyPressed() {
  if(keyCode === LEFT_ARROW) {
    pemain1.maju()
  }
  
  else if(keyCode === RIGHT_ARROW) {
    pemain2.maju()
  }
}